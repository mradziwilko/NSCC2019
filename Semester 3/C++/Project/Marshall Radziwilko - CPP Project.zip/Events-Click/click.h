#pragma once

#include <QWidget>

class Click : public QWidget {

  public:
    Click(QWidget *parent = 0);
};
