#pragma once

#include <QMainWindow>
#include <QApplication>

class AnotherMenu : public QMainWindow {

  public:
    AnotherMenu(QWidget *parent = 0);
};
